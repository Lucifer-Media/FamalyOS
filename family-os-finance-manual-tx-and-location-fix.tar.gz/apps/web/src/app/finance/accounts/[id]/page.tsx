'use client';

import { useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { AppShell } from '@/components/app-shell';
import { useRequireAuth } from '@/lib/use-require-auth';
import { apiFetch, ApiError } from '@/lib/api';
import { Button, Card, ErrorText, Badge } from '@/components/ui';
import { Upload, ArrowUpRight, ArrowDownLeft, Plus, Pencil, X } from 'lucide-react';

interface AccountDetail {
  id: string;
  title: string;
  attributes: { bankName?: string; currency?: string; accountType?: string };
}

interface TransactionSummary {
  id: string;
  title: string;
  attributes: {
    date: string;
    amount: number;
    currency: string;
    description: string;
    category?: string;
    transactionType?: string;
  };
}

interface StagedTransaction {
  date: string;
  amount: number;
  currency: string;
  description: string;
  counterparty?: string;
  category?: string;
  externalId: string;
  sourceFormat: string;
  isDuplicate: boolean;
}

// Частые категории — просто подсказки в datalist, пользователь может ввести свою.
const COMMON_CATEGORIES = [
  'Продукты', 'Транспорт', 'ЖКХ', 'Рестораны и кафе', 'Здоровье', 'Развлечения',
  'Одежда', 'Путешествия', 'Связь', 'Подписки', 'Между своими счетами', 'Зарплата', 'Прочее',
];

interface TransactionFormState {
  date: string;
  amount: string;
  category: string;
  description: string;
}

export default function AccountDetailPage() {
  const { loading, isAuthenticated } = useRequireAuth();
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [account, setAccount] = useState<AccountDetail | null>(null);
  const [transactions, setTransactions] = useState<TransactionSummary[]>([]);
  const [staged, setStaged] = useState<StagedTransaction[] | null>(null);
  const [detectedFormat, setDetectedFormat] = useState('');
  const [uploading, setUploading] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Ручное добавление / редактирование одной операции — одна и та же форма для обоих случаев.
  const [editingId, setEditingId] = useState<string | 'new' | null>(null);
  const [form, setForm] = useState<TransactionFormState>({ date: '', amount: '', category: '', description: '' });
  const [saving, setSaving] = useState(false);

  async function load() {
    const [acc, txs] = await Promise.all([
      apiFetch<AccountDetail>(`/entities/${params.id}`),
      apiFetch<TransactionSummary[]>(`/entities?entityType=financial_transaction`),
    ]);
    setAccount(acc);
    setTransactions((txs as any).filter((t: any) => t.attributes?.accountId === params.id));
  }

  useEffect(() => {
    load().catch((e) => setError(e.message));
  }, [params.id]);

  async function onUploadStatement(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      const form = new FormData();
      form.append('file', file);
      const result = await apiFetch<{ detectedFormat: string; warnings: string[]; transactions: StagedTransaction[] }>(
        `/finance/import/${params.id}/parse`,
        { method: 'POST', body: form, isForm: true },
      );
      setDetectedFormat(result.detectedFormat);
      setStaged(result.transactions);
      if (result.transactions.length === 0) {
        setError(result.warnings.join('; ') || 'В файле не найдено операций');
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Не удалось разобрать файл выписки');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function onConfirmImport() {
    if (!staged) return;
    setConfirming(true);
    setError('');
    try {
      const toImport = staged.filter((t) => !t.isDuplicate);
      const result = await apiFetch<{ created: number; skippedDuplicates: number }>('/finance/import/confirm', {
        method: 'POST',
        body: { accountEntityId: params.id, transactions: toImport },
      });
      setStaged(null);
      await load();
      alert(`Импортировано операций: ${result.created}. Пропущено дублей: ${result.skippedDuplicates}.`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Не удалось подтвердить импорт');
    } finally {
      setConfirming(false);
    }
  }

  function openNewTransaction() {
    setForm({ date: new Date().toISOString().slice(0, 10), amount: '', category: '', description: '' });
    setEditingId('new');
  }

  function openEditTransaction(t: TransactionSummary) {
    setForm({
      date: t.attributes.date,
      amount: String(t.attributes.amount),
      category: t.attributes.category ?? '',
      description: t.attributes.description ?? '',
    });
    setEditingId(t.id);
  }

  async function onSaveTransaction() {
    if (!account) return;
    setSaving(true);
    setError('');
    try {
      const amount = Number(form.amount);
      if (!form.date || Number.isNaN(amount)) {
        setError('Укажите дату и корректную сумму (отрицательная — расход, положительная — доход)');
        setSaving(false);
        return;
      }
      const attributes = {
        date: form.date,
        amount,
        currency: account.attributes.currency ?? 'RUB',
        accountId: params.id,
        description: form.description || (amount < 0 ? 'Расход' : 'Доход'),
        category: form.category || undefined,
        transactionType: amount < 0 ? 'EXPENSE' : 'INCOME',
        source: 'MANUAL',
      };
      if (editingId === 'new') {
        await apiFetch('/entities', {
          method: 'POST',
          body: { entityType: 'financial_transaction', title: `${form.date}: ${attributes.description}`, attributes },
        });
      } else if (editingId) {
        await apiFetch(`/entities/${editingId}`, {
          method: 'PATCH',
          body: { attributes },
        });
      }
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Не удалось сохранить операцию');
    } finally {
      setSaving(false);
    }
  }

  if (loading || !isAuthenticated) return null;

  const newCount = staged?.filter((t) => !t.isDuplicate).length ?? 0;
  const dupCount = staged?.filter((t) => t.isDuplicate).length ?? 0;

  return (
    <AppShell>
      <button onClick={() => router.push('/finance')} className="mb-3 text-sm text-ink/50 hover:underline">
        ← К списку счетов
      </button>

      {!account && !error && <p className="text-sm text-ink/50">Загрузка…</p>}
      <ErrorText>{error}</ErrorText>

      {account && (
        <>
          <div className="flex items-center justify-between">
            <h1 className="font-display text-xl font-semibold text-ink">{account.title}</h1>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={openNewTransaction}>
                <Plus size={16} /> Добавить операцию
              </Button>
              <input ref={fileInputRef} type="file" accept=".ofx,.csv,.xlsx,.xls" className="hidden" onChange={onUploadStatement} />
              <Button onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                <Upload size={16} /> {uploading ? 'Разбираем…' : 'Импортировать выписку'}
              </Button>
            </div>
          </div>

          {editingId && (
            <Card className="mt-4">
              <h2 className="font-display text-lg font-semibold">
                {editingId === 'new' ? 'Новая операция' : 'Редактирование операции'}
              </h2>
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs text-ink/50">Дата</label>
                  <input
                    type="date"
                    value={form.date}
                    onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
                    className="w-full rounded-card border border-line bg-paper px-3 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-ink/50">Сумма (отрицательная — расход)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={form.amount}
                    onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
                    className="w-full rounded-card border border-line bg-paper px-3 py-1.5 text-sm"
                    placeholder="-1500 или 50000"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-ink/50">Категория</label>
                  <input
                    list="category-suggestions"
                    value={form.category}
                    onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                    className="w-full rounded-card border border-line bg-paper px-3 py-1.5 text-sm"
                    placeholder="Продукты, Транспорт…"
                  />
                  <datalist id="category-suggestions">
                    {COMMON_CATEGORIES.map((c) => (
                      <option key={c} value={c} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-ink/50">Описание</label>
                  <input
                    value={form.description}
                    onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    className="w-full rounded-card border border-line bg-paper px-3 py-1.5 text-sm"
                  />
                </div>
              </div>
              <div className="mt-3 flex gap-2">
                <Button onClick={onSaveTransaction} disabled={saving}>
                  {saving ? 'Сохраняем…' : 'Сохранить'}
                </Button>
                <Button variant="secondary" onClick={() => setEditingId(null)}>
                  Отмена
                </Button>
              </div>
            </Card>
          )}

          {staged && (
            <Card className="mt-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold">Предпросмотр импорта</h2>
                <Badge tone="moss">{detectedFormat}</Badge>
              </div>
              <p className="mt-1 text-sm text-ink/60">
                Новых операций: <strong>{newCount}</strong>, уже импортировано ранее (пропускаются):{' '}
                <strong>{dupCount}</strong> из {staged.length} всего.
              </p>
              <div className="mt-3 max-h-64 overflow-y-auto">
                <table className="w-full text-xs">
                  <tbody>
                    {staged.slice(0, 200).map((t, i) => (
                      <tr key={i} className={t.isDuplicate ? 'opacity-40' : ''}>
                        <td className="py-1 pr-2 whitespace-nowrap">{t.date}</td>
                        <td className={`py-1 pr-2 text-right whitespace-nowrap ${t.amount < 0 ? 'text-clay' : 'text-moss-600'}`}>
                          {t.amount > 0 ? '+' : ''}
                          {t.amount} {t.currency}
                        </td>
                        <td className="py-1 pr-2 truncate">{t.description}</td>
                        <td className="py-1">{t.isDuplicate && <Badge tone="gold">дубль</Badge>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-3 flex gap-2">
                <Button onClick={onConfirmImport} disabled={confirming || newCount === 0}>
                  {confirming ? 'Импортируем…' : `Импортировать ${newCount} операций`}
                </Button>
                <Button variant="secondary" onClick={() => setStaged(null)}>
                  Отмена
                </Button>
              </div>
            </Card>
          )}

          <Card className="mt-4">
            <h2 className="font-display text-lg font-semibold">Операции</h2>
            <div className="mt-2 divide-y divide-line">
              {transactions
                .sort((a, b) => (a.attributes.date < b.attributes.date ? 1 : -1))
                .map((t) => (
                  <div key={t.id} className="group flex items-center justify-between py-2 text-sm">
                    <div className="flex items-center gap-2">
                      {t.attributes.amount < 0 ? (
                        <ArrowUpRight size={14} className="text-clay" />
                      ) : (
                        <ArrowDownLeft size={14} className="text-moss-600" />
                      )}
                      <div>
                        <p className="text-ink">{t.attributes.description}</p>
                        <p className="text-xs text-ink/40">
                          {t.attributes.date} {t.attributes.category ? `· ${t.attributes.category}` : ''}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className={t.attributes.amount < 0 ? 'text-clay' : 'text-moss-600'}>
                        {t.attributes.amount > 0 ? '+' : ''}
                        {t.attributes.amount} {t.attributes.currency}
                      </p>
                      <button
                        onClick={() => openEditTransaction(t)}
                        className="opacity-0 transition-opacity hover:text-clay group-hover:opacity-100"
                        title="Редактировать"
                      >
                        <Pencil size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              {transactions.length === 0 && <p className="py-2 text-sm text-ink/50">Операций пока нет.</p>}
            </div>
          </Card>
        </>
      )}
    </AppShell>
  );
}
